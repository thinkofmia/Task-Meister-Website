<?php 
// No direct access
defined('_JEXEC') or die; 
//Displays module output
?>
 
<h3>User Stats</h3>