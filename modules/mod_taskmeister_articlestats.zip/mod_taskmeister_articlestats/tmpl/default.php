<?php 
// No direct access
defined('_JEXEC') or die; 
//Displays module output
?>

<h3>Article Stats</h3>