<?php 
// No direct access
defined('_JEXEC') or die; 
//Displays module output
?>

<?php echo $displayText; ?>