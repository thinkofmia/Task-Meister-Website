<?php 
// No direct access
defined('_JEXEC') or die; 
//Displays module output
?>

<h3>Table of Articles</h3>